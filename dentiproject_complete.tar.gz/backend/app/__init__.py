"""DentiProject backend application package."""
